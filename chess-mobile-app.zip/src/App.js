import React, { useState } from "react";
import Chessboard from "chessboardjsx";
import { Chess } from "chess.js";

export default function App() {
  const [game, setGame] = useState(new Chess());
  const [fen, setFen] = useState("start");
  const [level, setLevel] = useState("300");

  const makeAIMove = () => {
    if (game.isGameOver()) return;

    const moves = game.moves();
    let move;

    if (level === "300") {
      // Joue un coup aléatoire
      move = moves[Math.floor(Math.random() * moves.length)];
    } else if (level === "800") {
      // Joue le meilleur coup simple (capture prioritaire sinon random)
      move = moves.find(m => m.includes("x")) || moves[Math.floor(Math.random() * moves.length)];
    } else if (level === "1500") {
      // IA basique : essaie de maximiser le matériel avec un simple score
      let bestScore = -Infinity;
      moves.forEach(m => {
        game.move(m);
        const score = materialScore(game);
        game.undo();
        if (score > bestScore) {
          bestScore = score;
          move = m;
        }
      });
    }

    game.move(move);
    setFen(game.fen());
  };

  const materialScore = (g) => {
    const fen = g.fen().split(" ")[0];
    let score = 0;
    for (let c of fen) {
      if (c === "p") score -= 1;
      if (c === "n" || c === "b") score -= 3;
      if (c === "r") score -= 5;
      if (c === "q") score -= 9;
      if (c === "P") score += 1;
      if (c === "N" || c === "B") score += 3;
      if (c === "R") score += 5;
      if (c === "Q") score += 9;
    }
    return score;
  };

  const onDrop = ({ sourceSquare, targetSquare }) => {
    const move = game.move({ from: sourceSquare, to: targetSquare, promotion: "q" });
    if (move === null) return;
    setFen(game.fen());
    setTimeout(makeAIMove, 500);
  };

  const resetGame = () => {
    const newGame = new Chess();
    setGame(newGame);
    setFen("start");
  };

  return (
    <div style={{ maxWidth: 360, margin: "auto", padding: 20, textAlign: "center" }}>
      <h1 style={{ fontSize: 24, marginBottom: 16 }}>Joue contre ChatGPT Chess Bot</h1>
      <select value={level} onChange={(e) => setLevel(e.target.value)} style={{ marginBottom: 16, padding: 8, fontSize: 16 }}>
        <option value="300">Niveau 300</option>
        <option value="800">Niveau 800</option>
        <option value="1500">Niveau 1500</option>
      </select>
      <Chessboard
        width={320}
        position={fen}
        onDrop={onDrop}
        boardStyle={{ borderRadius: "10px", boxShadow: "0 5px 15px rgba(0,0,0,0.3)" }}
      />
      <button onClick={resetGame} style={{ marginTop: 20, padding: 10, fontSize: 16, backgroundColor: "#2563eb", color: "white", border: "none", borderRadius: 6 }}>
        Recommencer la partie
      </button>
    </div>
  );
}