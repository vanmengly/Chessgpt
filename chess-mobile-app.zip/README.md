# Chess Mobile App

Application React pour jouer aux échecs contre une IA simulant plusieurs niveaux (300, 800, 1500 elo).

## Instructions déploiement Vercel

1. Crée un dépôt GitHub vide.
2. Copie tous les fichiers du projet dans ce dépôt.
3. Connecte ce dépôt à Vercel (https://vercel.com/new).
4. Déploie en quelques clics.
5. Profite de l'application sur mobile.

---